const randColor = function () {
    var r = 50 + Math.floor(Math.random() * 200);
    var g = 50 + Math.floor(Math.random() * 200);
    var b = 50 + Math.floor(Math.random() * 200);
    return "rgb( " + r + ", " + g + ", " + b + ")";
}
const randSize = function () {
    return (14 + Math.floor(Math.random() * 3)) + "px";
}

export default {
    randColor, randSize
}