import Head from 'next/head'
import RightContent from '../component/RightContent'
import Request from '../services/request'
import base from '../styles/base.module.css'
import comment from '../styles/comment.module.css'
import bg from '../styles/blogDetail.module.css'

// 留言page页
export default function Comment({tags,hots}) {
  return (
    <div>
      <Head>
        <title>留言</title>
      </Head>
      {/* 留言part */}
      {/* <div className={base.content_left}>
        <div id="comment">
          <p>
            欢迎灌水交流，别看我长时间不发博，博主可一直都在线~<br />
            <br />
            友链只交换技术类个人博客。<br />
            <br />
            不要皮，谢谢。<br />
            <br />
            博主联系:MzcxasdasdaNjA0Nzg1<br />
          </p>
        </div>
        <div id="blogComment">
          <ul>
            {commentList.map((item, index) => {
              return <li key={index}>
                <span> {item.name}：发表于 {item.ctime}<a href="#" onClick={huifu(item.id)}>[回复]</a></span>
                <p>{item.content}</p>
              </li>
            })}
          </ul>
          <div className={bg.addComment} id="addComment">
            <input type="hidden" v-model="commentId" />
            <input type="text" placeholder="昵称" v-model="name" />
            <input type="text" placeholder="邮箱" v-model="email" />
            <textarea placeholder="无意义的内容我可能不会回复你" v-model="comment"></textarea>
            <input type="text" placeholder="请在这里输入验证码" v-model="inputRandomCode" /><span v-html="randomSvg" onClick={changeCode}></span>
            <button onClick={sendComment}>提交留言</button>
          </div>
        </div>
      </div> */}
      {/* 右边部分 */}
			<RightContent tag={tags} hot={hots} />
    </div >
  );
};

export async function getStaticProps() {
	const respTag = await Request.get('/api/tags')
	const respHot = await Request.get('/api/blog/hot')
	return {
	  props: {
		tags: respTag.data.data,//标签展示列表  
		hots: respHot.data.data,//博客热门
	  }
	};
  }