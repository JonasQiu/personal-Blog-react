
import styles from '../styles/login.module.css'
import Head from 'next/head'
import { useState } from 'react'

// 登陆page页
export default function Login() {

	const [isSignUp, setisSignUp] = useState(false)

	
	return (
		<div className={styles.body}>
			<Head>
				<title>登陆</title>
			</Head>
			<div className={styles.main}>
				<h1 className={styles.h1}>个人博客登陆</h1>
				<div className={styles.loginForm}>
					<div className={styles.w3lsTabs}>
						<div id="horizontalTab" className={styles.horizontalTab}>
							<ul className="resp-tabs-list">
								<li className={styles.respTabItem} onClick={() => {setisSignUp(false)}}><span>Login</span></li>
								<li className={styles.respTabItem} onClick={() => {setisSignUp(true)}}><span>/</span><span>Sign up</span></li>
							</ul>
							<div className={styles.clear}> </div>
							<div className={styles.respTabsContainer}>
								{isSignUp ? (<div aria-labelledby="tab_item-1">
									<div className={styles.loginAgileitsTop}>
										<form action="#" method="post">
											<p>User Name </p>
											<input type="text" name="User Name" required="" />
											<p>Your Email </p>
											<input type="text" name='Email' required="" />
											<p>Password</p>
											<input type="password" name="Password" placeholder="" required="" />
											<input type="checkbox" id="brand1" value="" />

											<label htmlFor="brand1"><span></span>I accept the terms Use</label>
											{/* 个人博客说明，点击跳转一个说明，选中才能登陆 */}
											<input type="submit" value="SIGN UP" />
										</form>
									</div>
								</div>
								) : (<div aria-labelledby="tab_item-0">
									<div className={styles.loginAgileitsTop}>
										<form action="#" method="post">
											<p>User Name </p>
											<input type="text" name="UserName" required="" />
											<p>Password</p>
											<input type="password" name="Password" required="" />
											<input type="checkbox" id="brand" value="" />

											<label htmlFor="brand"><span></span> Remember me ?</label>
											{/* 本地缓存账号密码 */}
											<input type="submit" value="LOGIN" />
										</form>
									</div>
									<div className={styles.loginAgileitsBottom}>
										{/* 添加对密码的去除 */}
										<p><a href="#">Forgot password?</a></p>
									</div>
								</div>)}
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}