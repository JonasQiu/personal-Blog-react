import '../styles/globals.css'
import Header from '../component/Header'
import Footer from '../component/Footer'
import { useRouter } from 'next/router'

// 根组件模板
function MyApp({ Component, pageProps }) {
  const router = useRouter();
 
  // console.log(router.pathname)
  if (router.pathname == '/login') {
    return <Component {...pageProps} />
  } else if (router.pathname == '/404') {
    return <Component />
  } else {
    return (
      <div id='goToTop'>
        <Header />
        <Component {...pageProps} />
        <Footer />
        {/* 点击回到头部 */}
        <a href="#goToTop" className='goToTop'>&#8593;</a>
      </div>

    )
  }
}

export default MyApp
