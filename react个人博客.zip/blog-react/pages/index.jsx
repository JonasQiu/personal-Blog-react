import Head from 'next/head'
import styles from '../styles/index.module.css'
import base from '../styles/base.module.css'
import RightContent from '../component/RightContent'
import Request from '../services/request'
import { useRouter } from 'next/router'
import { useState } from 'react'
import TurnPage from '../component/TurnPage'
import BlogList from '../component/blogList'

// 首页page页
export default function Index({ eecontent, tags, blogs, hots }) {
  const router = useRouter();
  // 每日一句
  const [content, setcontent] = useState(eecontent);
  // 博客列表
  const [list, setlist] = useState(blogs.arr)

  // 翻页更新list数据
  function changePage(res) {
    res.then(res=>setlist(res.data.data.arr))
  }

  return (
    <div className={styles.body} >
      <Head>
        <title>博客首页</title>
      </Head>
      {/* 左边部分 */}
      <div className={base.content_left}>
        {/* 每日一句 */}
        <div className={styles.everyDay}>
          <div onClick={() => {
            router.push("/ee");
          }} className={styles.everyDayTitle} style={{ cursor: 'pointer' }}>每日一句</div>
          <p>{content['content']}</p>
          <p style={{ textAlign: "right", marginRight: '30px' }}>————{content["author"]}</p>
        </div>
        {/* 博客展示 */}
        <div className={styles.blogList}>
          <ul>
            {list.map((item, index) => {
              return (
                <li key={index} onClick={() => {
                  // 跳转详情页
                  router.push(`/blogDetail/${item.id}`)
                }
                }>
                  <span >{item.title}</span>
                  {<BlogList content = {item.content}></BlogList>}
                  <div><span>发布于:&nbsp;&nbsp;{item.createdAt}&nbsp;&nbsp; |&nbsp;&nbsp; 更新于:&nbsp;&nbsp; {item.updatedAt}&nbsp;&nbsp; |&nbsp;&nbsp; 浏览&nbsp; ({item.view})&nbsp;&nbsp; |&nbsp;&nbsp; Tags:&nbsp;&nbsp;{item.tags}</span></div>
                </li>)
            })}
          </ul>
        </div>
        {/* 翻页 */}
        <div className={styles.pageTools}>
          <TurnPage option={changePage} />
        </div>
      </div>
      {/* 右边部分 */}
      <RightContent tag={tags} hot={hots} />
    </div >
  );
};

export async function getStaticProps() {
  const respEe = await Request.get('/api/everyday');
  const respTag = await Request.get('/api/tags')
  const respBlog = await Request.get('/api/blog')
  const respHot = await Request.get('/api/blog/hot')
  return {
    props: {
      eecontent: (respEe.data.data[Math.round(Math.random() * 4)]),// 5条数据随机
      tags: respTag.data.data,//标签展示列表  
      blogs: respBlog.data.data,//博客列表
      hots: respHot.data.data,//博客热门
    }
  };
}