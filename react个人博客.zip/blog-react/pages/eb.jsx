import Head from 'next/head'
import EditorRich from '../component/EditorRich/index.jsx'

// 编辑博客page页,先处理富文本组件再写
export default function eb() {
  return (
    <div>
      <Head>
        <title>编辑博客</title>
      </Head>
      <EditorRich />
    </div>
  );
}