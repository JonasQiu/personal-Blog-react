import Head from 'next/head'
import base from '../styles/base.module.css'
import ee from '../styles/ee.module.css'
import { useState } from 'react'
import Request from '../services/request'

// 编辑每日一句page页
export default function Ee() {
  const [content, setcontent] = useState('')
  return (
    <div>
      <Head>
        <title>添加标签</title>
      </Head>
      <div className={base.content_left}>
        <h1 className={ee.edit}>添加标签</h1>
        <input placeholder="请输入添加标签" id="content" value={content} onChange={(e) => {
          setcontent(e.target.value)
        }}></input >
        <button className={ee.submit} onClick={async () => {
          // 添加标签
          if (content.trim()) {
            await Request.post('/api/tags', {
              tag: content
            }).then(res => {
              alert(res.data.data)
            })
          }
        }}>提交</button>
      </div>
    </div>
  );
};
