import Head from 'next/head'
// import map from '../styles/map.module.css'

// 地图page页
export default function Map() {
  return (
    <div>
      <Head>
        <title>地图</title>
      </Head>
      {/* 地图详情 */}
      {/* <div>
        <h2>个人博客's Map</h2>
        <div className={map.margin}><a href="/" style="font-size: 14px;">个人博客首页</a> &gt;&gt; <a href="#" style="color: #222;font-size: 12px;">站点地图</a></div>
        <div className={map.margin}>
          <h3>最新文章</h3>
          <ul className={map.ul} id="blogs">
            {blogList.map((item,index) => {
              return <li key={index} className={map.li} ><a onClick={jumpTo(item.id)}>{item.title}</a></li>
            })}
          </ul>
        </div>
      </div> */}
    </div>
  );
};

