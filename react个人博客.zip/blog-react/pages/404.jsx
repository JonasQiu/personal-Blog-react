export default function Error() {
  return <h1>404 not found</h1>
}
