import Head from 'next/head'
import RightContent from '../component/RightContent'
import base from '../styles/base.module.css'
import about from '../styles/about.module.css'
import Request from '../services/request'

// 关于page页
export default function About({tags,hots}) {
	return (
		<div>
			<Head>
				<title>关于</title>
			</Head>
			{/* 关于part */}
			<div className={base.content_left}>
				{/* <div id="about">
					<h1 onClick={goto}>关于我</h1>
					<p>
						博主丘金龙，性别男，广东省。<br />
					<br />
						只学习了一年前端的全栈程序员
					<br />
						认为JS是世界上最好的语言
					<br />
						电商行业
					<br />
					<br />
						我的书单：https://book.douban.com/people/58553308/<br />
						我的知乎：https://www.zhihu.com/people/zheng-xiao-93-51/activities</p><br />
				</div> */}
				<div id="blogComment">
					{/* 留言 */}
					{/* <ul>
						{
							commentList.map((item, index) => {
								return <li key={index}>
									<span> {item.name}：发表于 {item.ctime}<a href="#" onClick={huifu(item.id)}>[回复]</a></span>
									<p>{item.content}</p>
								</li>
							})
						}
					</ul> */}
					{/* 添加留言 */}
					{/* <div className={about.addComment} id="addComment">
						<input type="hidden" v-model="commentId" />
						<input type="text" placeholder="昵称" v-model="name" />
						<input type="text" placeholder="邮箱" v-model="email" />
						<textarea placeholder="无意义的内容我可能不会回复你" v-model="comment"></textarea>
						<input type="text" placeholder="请在这里输入验证码" v-model="inputRandomCode" /><span v-html="randomSvg" onClick={changeCode}></span>
						<button onClick={sendComment}>提交留言</button>
					</div> */}
				</div>
			</div>
			{/* 右边部分 */}
			<RightContent tag={tags} hot={hots} />
		</div>
	)
}

export async function getStaticProps() {
	const respTag = await Request.get('/api/tags')
	const respHot = await Request.get('/api/blog/hot')
	return {
	  props: {
		tags: respTag.data.data,//标签展示列表  
		hots: respHot.data.data,//博客热门
	  }
	};
  }