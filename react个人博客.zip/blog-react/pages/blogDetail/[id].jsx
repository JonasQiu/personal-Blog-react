import { useRouter } from "next/router";
import base from '../../styles/base.module.css'
import bg from '../../styles/blogDetail.module.css'
import Request from '../../services/request'
// 路由配置:/blogDetail/123123
export default function blogDetail({ detail }) {
    const router = useRouter();
    if (router.isFallback) {
        return <h1>Loading...</h1>;
    }
    return (
        <div className={base.content_left}>
            <div id="blogDetail">
                <h1>{detail.title}</h1>
                <span>作者:&nbsp;&nbsp; {detail.author}&nbsp;&nbsp; 发布于:&nbsp;&nbsp; {detail.createdAt} &nbsp;&nbsp;更新于:&nbsp;&nbsp; {detail.updatedAt}&nbsp;&nbsp; 浏览&nbsp;({detail.view})</span>
                <div id="blog_content" >{detail.content}</div>
            </div>
            <div id="blogComment">
                {/* <ul>
                    {commentList.map((item, index) => {
                        return <li key={index}>
                            <span> {item.name}：发表于 {item.ctime}<a href="#" onClick={huifu(item.id)}>[回复]</a></span>
                            <p>{item.detail}</p>
                        </li>
                    })}
                </ul> */}
                <div className={bg.addComment} id="addComment">
                    {/* <input type="hidden" v-model="commentId" />
                    <input type="text" placeholder="昵称" v-model="name" />
                    <input type="text" placeholder="邮箱" v-model="email" />
                    <textarea placeholder="无意义的内容我可能不会回复你" v-model="comment"></textarea>
                    <input type="text" placeholder="请在这里输入验证码" v-model="inputRandomCode" /><span v-html="randomSvg" onClick={changeCode}></span>
                    <button onClick={sendComment}>提交留言</button> */}
                </div>
            </div>
        </div>
    );
};

// SSG
export async function getStaticProps({ params }) {
    const resp = await Request.get(`/api/blog/${params.id}`);

    //打开页面，增加一次阅读量view
    const resView = await Request.get(`/api/blog/view/${params.id}`)
    await Request.put(`/api/blog/view/${params.id}`, {
        view: JSON.stringify(parseInt(resView.data.data[0].view) + 1)
    })

    return {
        props: {
            detail: resp.data.data[0]
        }
    };
}

//该函数用于得到有哪些可能出现的id
export async function getStaticPaths() {
    const resp = await Request.get('/api/blog');
    const paths = resp.data.data.arr.map(m => ({
        params: {
            id: JSON.stringify(m.id)
        }
    }));
    return {
        paths,
        fallback: true
    };
}