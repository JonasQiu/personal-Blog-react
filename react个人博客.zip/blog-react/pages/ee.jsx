import Head from 'next/head'
import base from '../styles/base.module.css'
import ee from '../styles/ee.module.css'
import { useState } from 'react'
import Request from '../services/request'

// 编辑每日一句page页
export default function Ee() {
  const [content, setcontent] = useState('')
  const [author, setauthor] = useState('')
  return (
    <div>
      <Head>
        <title>编辑每日一句</title>
      </Head>
      <div className={base.content_left}>
        <h1 className={ee.edit}>编辑每日一句</h1>
        <input placeholder="请输入每日一句" id="content" value={content} onChange={(e) => {
          setcontent(e.target.value)
        }}></input>
        <input placeholder="请输入作者" id="content" value={author} onChange={(e) => {
          setauthor(e.target.value)
        }}></input>
        <button className={ee.submit} onClick={async () => {
          // 提交每日一句
          if (content.trim()) {
            await Request.post('/api/everyday', {
              content, author
            }).then(res => {
              alert(res.data.data)
            })
          }
        }}>提交</button>
      </div>
    </div>
  );
};
