import axios from "axios";
import cookie from "cookie";

export function getServerInstance(req) {
  const config = {
    baseURL: "http://127.0.0.1:7001/"
  };
  if (req) {
    const cookies = req.headers["cookie"];
    const cookieObj = cookie.parse(cookies);
    if (cookieObj.token) {
      config.headers = {
        authorization: cookieObj.token
      };
    }
  }
  return axios.create(config);
}

let instance = getServerInstance();

export default instance