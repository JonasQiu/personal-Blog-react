import base from '../../styles/base.module.css'
import { useRouter } from 'next/router'
import { useState } from "react";

// 头部的组件
const Header = () => {
	const [isLogin, setisLogin] = useState('a')
	const [userName, setuserName] = useState('Jonas')
	const router = useRouter();
	return (
		<div className={base.header}>
			<div className={base.content}>
				<div className={base.myactive} onClick={() => {
					router.push("/");
				}}>
					<a>Jonas个人博客 | 技术博客</a>
				</div>
				<ul>
					<li onClick={() => {
						router.push("/");
					}}>
						<a>首页</a>
					</li>
					<li onClick={() => {
						router.push("/map");
					}}>
						<a>地图</a>
					</li>
					<li onClick={() => {
						router.push("/about");
					}}>
						<a>关于</a>
					</li>
					<li onClick={() => {
						router.push("/comment");
					}}>
						<a>留言</a>
					</li>
				</ul>
				<input type="text" placeholder="输入关键词查找" />
				<button >搜索</button>
				<div className={base.logincontent}>
					{isLogin ? (
						<div className={base.haveLogin}>
							<div className={base.userName}>{userName}</div>
							<div className={base.login}>注销</div>
						</div>
					) : (<div className={base.login}>登陆</div>)}
				</div>
			</div>
		</div>
	);
};

export default Header;