import base from '../../styles/base.module.css'
import { useState, useRef } from 'react'

// 尾部组件
export default function Footer(ref) {
    const [userName, setuserName] = useState('Jonas')
    const foot = useRef()

    return (
        <div className={base.footer} ref={foot}>
            Copyright © 2010-2019 {userName}个人博客 All rights reserved. 由免费开源的WordPress强力驱动. 鲁ICP备14017955号站长统计
        </div>
    )
}