import { useState, useEffect } from 'react'
import Request from '../../services/request'

function turnPage({ option }) {
    const [nowPage, setnowPage] = useState(1)
    const [allPage, setallPage] = useState(1)
    // 默认3条数据
    const [limit, setlimit] = useState(3)

    // 回调函数,将该翻页更改的获取的数据返回出去
    const func = option

    //副作用：获取博客总数
    useEffect(async () => {
        await Request.get('/api/blog').then(res => {
            setallPage(res.data.data.count[0]['count(id)'])
        })
        return () => {
            setallPage(1)
        }
    }, [])

    // 获取翻页数据
    async function requestData(now) {
        // console.log(now, limit)//打印的数据是上次的
        // -1的原因是不要跳过当前页的数据，跳过上页的数据就行
        const skip = (now - 1) * limit
        return await Request.get('/api/blog', {
            skip,
            limit
        })
    }
    // 获取中间五个数字
    function randNode() {
        const arr = []
        for (let i = nowPage - 2; i < nowPage + 2; i++) {
            if (i > 1 && i < allPage) {
                arr.push(<li className={i === nowPage ? 'current' : ''} key={i} onClick={async () => {
                    setnowPage(i)
                    await func(requestData(nowPage))
                }}>{i}</li>)
            }
        }
        return arr
    }

    const template = (
        <div>
            <ul className="page-ul">
                {/* 添加上一页node */}
                {(nowPage > 1) ? (<li className="prev-page" onClick={async () => {
                    setnowPage((n) => n - 1)
                    await func(requestData(nowPage))
                }}>上一页</li>) : ''}
                {/* 添加第一页 */}
                <li className={1 === nowPage ? 'current' : ''} onClick={async () => {
                    setnowPage(1)
                    await func(requestData(nowPage))
                }} >1</li>
                {/* 添加省略号node */}
                {(nowPage - 2 > 2) ? (<span>...</span>) : ''}
                {/* 添加中间5页node */}
                {
                    randNode()
                }
                {/* 添加省略号node */}
                {(nowPage + 2 < allPage - 1) ? (<span>...</span>) : ''}
                {/* 添加最后一页 */}
                {(nowPage != 1) ? (<li className={allPage === nowPage ? 'current' : ''} onClick={async () => {
                    setnowPage(allPage)
                    await func(requestData(nowPage))
                }}>{allPage}</li>) : ''}
                {/* 添加下一页node */}
                {(nowPage < allPage) ? (<li className="next-page" onClick={async () => {
                    setnowPage((n) => n + 1)
                    await func(requestData(nowPage))
                }}>下一页</li>) : ''}
            </ul>
        </div>
    )
    return template
}

export default turnPage