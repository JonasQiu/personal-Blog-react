import React from 'react'

export default function BlogList({content}){
    // React.createElement('',{},'')
    return (
        <iframe
        title="resg"
        srcDoc={content}
        style={{ width: '100%', border: '0px',overflow:'hidden',height:'150px'}}
        sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
        scrolling="auto"
      />
    )
    // return (<p >
    //     {content}
    // </p>)
}