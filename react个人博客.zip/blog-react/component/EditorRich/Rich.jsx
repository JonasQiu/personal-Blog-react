import React, { useState, useEffect } from 'react';
import E from 'wangeditor'
import eb from '../../styles/eb.module.css'
import Request from '../../services/request'

let editor = null
function App() {
    const [content, setContent] = useState('')
    const [tag, setTag] = useState('')
    const [title, setTitle] = useState('')
    useEffect(() => {
        // 注：class写法需要在componentDidMount 创建编辑器
        editor = new E("#div1")
        editor.config.onchange = (newHtml) => {
            setContent(newHtml)
        }
        /**一定要创建 */
        editor.create()
        return () => {
            // 组件销毁时销毁编辑器  注：class写法需要在componentWillUnmount中调用
            editor.destroy()
        }
    }, [])

    // 提交博客
    function submit() {
        Request.post('/api/blog', {
            content,
            author:'jonas',
            title,
            tags:tag,
            tagId:'6',
            userId:'1'
        }).then(res => {
            alert(res.data.data)
        })
    }

    return (
        <div>
            <div className={eb.wrap}>
                <h1>文章编辑</h1>
                <input type="text" name='defaultInp' value={title} onChange={(e) => {
                    setTitle(e.target.value)
                }} placeholder="请输入文章标题" />
                <input type="text" name='defaultInp' value={tag} onChange={(e) => {
                    setTag(e.target.value)
                }} placeholder="请输入标签，用逗号隔开" />
                <div id="div1" ></div>
            </div>
            <button className={eb.btn} onClick={submit}>提交</button>
        </div>
    );
}
export default App;
