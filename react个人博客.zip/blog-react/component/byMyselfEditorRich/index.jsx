import dynamic from 'next/dynamic'

const E = dynamic(()=>import('./Rich'))

export default E