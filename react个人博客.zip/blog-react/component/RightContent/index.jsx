import base from '../../styles/base.module.css'
import random from '../../util/random'
import { useState } from 'react'

import dynamic from 'next/dynamic' 
//无法使用dyncmic来取消ssr。因为该组件使用了属性传递，目前官方没有明确规定来说明传递属性

// 右侧内容的组件
function RightContent({ tag, hot }) {
    // 处理api，将api的数据添加到下面2个数组中
    // 标签 ,30条数据
    const [tags, settags] = useState(tag)
    // 最近热门，5条数据,Request
    const [blogList, setblogList] = useState(hot)

    // jsx
    const template = (
        <div className={base.content_right}>
            <div className={base.tags_cloud}>
                <span>随机标签云</span>
                <div>{tags.map((item, index) => {
                    return <a key={index} style={{ color: '#fff', padding: '5px 10px', borderRadius: '10px', background: random.randColor(), fontSize: random.randSize() }}  >{item.tagsName}</a>
                    // href={item.url}
                })}</div>
            </div>
            <div className={base.hot_blog}>
                <span>最近热门</span>
                <ul>
                    {blogList.map((item, index) => {
                        return <li key={index}><a href={item.url}>{item.title}</a></li>
                    })}
                </ul>
            </div >
        </div >
    )
    return template
}
export default RightContent